--- STEAMODDED HEADER
--- MOD_NAME: Abstract Mod
--- MOD_ID: ABSTRACTMOD
--- MOD_AUTHOR: [SrMario]
--- MOD_DESCRIPTION: This is a vanilla mod that expands some game mechanics, such as jokers, enchantments, and consumables (Sorry for my bad english)
--- PREFIX: abstract
--- VERSION: 1.0.0
--- BADGE_COLOUR: FF3658
--- BADGE_TEXT_COLOUR: FFFFFF
----------------------------------------------
------------MOD CODE -------------------------


SMODS.Atlas {
    key = 'modicon',
    px = 32,
    py = 32,
    path = 'modicon.png'
}

SMODS.Atlas {
    key = 'All_jokers_atlas',
    px = 71,
    py = 95,
    path = 'Jokers.png'
}

SMODS.Atlas {
    key = 'New_jokers_atlas',
    px = 71,
    py = 95,
    path = 'Abstract_jokers.png'
}

SMODS.Atlas {
    key = 'All_enhancements_atlas',
    px = 71,
    py = 95,
    path = 'card_backs.png'
}

SMODS.Atlas {
    key = 'All_consumables_atlas',
    px = 71,
    py = 95,
    path = 'Abstract_consumables.png'
}

SMODS.Atlas {
    key = 'joker_atlas_150',
    px = 71,
    py = 95,
    path = 'Jokers_1.5.0.png'
}

SMODS.Atlas {
    key = 'All_vouchers_atlas',
    px = 71,
    py = 95,
    path = 'Vouchers.png'
}




SMODS.Joker{
    key = "randomchips",
    loc_txt = {
        name = 'Chip Chip',
        text = 
        {
            '',
        }
    },
    pos = {x = 0, y = 0},
    atlas = 'All_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 5, 
    rarity = 3,
    config = { extra = {
        min = 0,
        max = 250,
        chip_mod = 0
    }
},
loc_vars = function(self,info_queue,center)

    local prefixes = {
            { string = '+', colour = G.C.CHIPS },   
            { string = '@#', colour = G.C.MULT }, 
            { string = '404', colour = G.C.MULT},
            { string = 'NOT', colour = G.C.MULT},
             { string = '-', colour = G.C.CHIPS }, 
        }
    local loc_chips = localize('k_chips')
    local loc_glitch = '???'
    local loc_glitch1 = 'FOUND'
    local loc_glitch2 = 'MISS'
    local loc_glitch3 = 'chips'
    
    main_start = {
            -- First part: Rotating prefix symbols (+, X, $, @#)
            { n = G.UIT.O, config = { object = DynaText({ 
                string = prefixes, 
                pop_in_rate = 9999999, 
                silent = true, 
                random_element = true, 
                scale = 0.35, 
                min_cycle_time = 0 
            }) } },
            
            -- Second part: Rotating values based on reward type
            { n = G.UIT.O, config = { object = DynaText({ 
                string = {'20','33','1','??','16','!!?','99','1@','02','OF','##'}, 
                colours = { G.C.BLUE }, 
                pop_in_rate = 9999999, 
                silent = true, 
                random_element = true, 
                pop_delay = 0.5, 
                scale = 0.35, 
                min_cycle_time = 0 
            }) } },
            
            { n = G.UIT.O, config = { object = DynaText({
                string = {
                    { string = loc_chips, colour = G.C.CHIPS },
                    { string = loc_glitch, colour = G.C.MULT },
                    { string = loc_glitch1, colour = G.C.CHIPS },
                    { string = loc_glitch2, colour = G.C.MULT },
                    { string = loc_glitch3, colour = G.C.CHIPS },
                    
                },
                pop_in_rate = 9999999,
                silent = true,
                random_element = true,
                pop_delay = 0.2,
                scale = 0.35,
                min_cycle_time = 0
            }) } },
        }
        
        return { main_start = main_start }
end,

    calculate = function(self,card,context)
        if context.joker_main then
            local temp_chips = pseudorandom(pseudoseed('chips'), -card.ability.extra.min, card.ability.extra.max)
            return
            {
                chip_mod = card.ability.extra.chip_mod + temp_chips ,
                message = '+' .. card.ability.extra.chip_mod + temp_chips ,
                colour = G.C.CHIPS,
                card = card
            }
        end
    end

}

SMODS.Joker{
    key = "bananapeel",
    loc_txt = {
        name = 'Banana Peel',
        text = 
        {
            '{C:green}#1# in #2#{} chance to  ',
            'add {X:mult,C:white}X#3#{} Mult'
        }
    },
    pos = {x = 1, y = 0},
    atlas = 'New_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 2, 
    rarity = 1,
    pools = {
        Food = true
    },
    config = { extra = {
        Xmult = 2,
        odds = 4
    }
},
loc_vars = function(self,info_queue,center)
    return {vars = {G.GAME.probabilities.normal,center.ability.extra.odds,center.ability.extra.Xmult}} 
end,

calculate = function(self,card,context)
    
    if context.joker_main then
        if pseudorandom('bananapeel') < G.GAME.probabilities.normal/card.ability.extra.odds then
        return
        {
            card = card,
            Xmult_mod = card.ability.extra.Xmult,
            message = 'X' .. card.ability.extra.Xmult .. ' Mult',
            colour = G.C.MULT
        }
    else
        return 
        {
            card = card,
            message = 'Maybe Not'
        }
        end
    end


end

}

SMODS.Joker{
    key = "jimba",
    loc_txt = {
        name = 'Jimba',
        text = 
        {
       '{C:green}#3# in #2#{} chance to card',
        'permanently gains {C:blue}+#1#{} Chips',
        '{C:attention}held in hand{}',
        }
    },
    pos = {x = 3, y = 0},
    atlas = 'New_jokers_atlas',
    blueprint_compat = true,
    unlocked = true, 
    discovered = false, 
    cost = 5, 
    rarity = 2,
    config = { extra = {
        chip_mod = 3,
        odds = 2

    }
},
    loc_vars = function(self,info_queue,center)
        return {vars = {center.ability.extra.chip_mod, center.ability.extra.odds, G.GAME.probabilities.normal}} 
    end,
    calculate = function(self,card,context)
         if context.individual and context.cardarea == G.hand and not context.other_card.debuff and not context.end_of_round then
             if pseudorandom('jimba') < G.GAME.probabilities.normal/card.ability.extra.odds then
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus or 0
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus + card.ability.extra.chip_mod
                return {
                    extra = {message = localize('k_upgrade_ex'), colour = G.C.CHIPS},
                    colour = G.C.CHIPS,
                    card = card
                }
            end
         end
    end

}

SMODS.Joker{
    key = "Ducks",
    loc_txt = {
        name = 'See the stars',
        text = 
        {
            'Creates a {C:planet}Planet{} card with',
            '{C:dark_edition}Foil{} edition of the',
            '{C:attention}played poker{} hand in',
            'your {C:attention}first hand{}',
            'in the {C:attention}Small or Big blind.{}',
            '{C:inactive}(Must have room){}'
        }
    },
    pos = {x = 5, y = 0},
    atlas = 'All_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 7, 
    soul_pos = { x = 3, y = 2},
    rarity = 3,
    calculate = function(self,card,context)
    if context.before then
      if G.GAME.current_round.hands_played == 0 and #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
        if not G.GAME.blind.boss then
        local card_type = 'Planet'
          G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
          G.E_MANAGER:add_event(Event({
            trigger = 'before',
            delay = 0.0,
            func = function()
              local _planet = 0
              for k, v in pairs(G.P_CENTER_POOLS.Planet) do
                if v.config.hand_type == context.scoring_name then
                  _planet = v.key
                end
              end
              local card = create_card(card_type, G.consumeables, nil, nil, nil, nil, _planet, nil)
              card:add_to_deck()
              card:set_edition({foil = true},true)
              G.consumeables:emplace(card)
              G.GAME.consumeable_buffer = 0
              return true
            end
          })
          )

          return {
            message = 'Cuak',
            colour = G.C.SECONDARY_SET.Planet
          }
        end
      end
    end
end

}


SMODS.Joker{
    key = "Underpants",
    loc_txt = {
        name = 'Nice Underpants',
        text = 
        {
            'This Joker gains {C:blue}+#1#{} Chips',
            'if played hand conteins',
            '{C:attention}Three of a Kind{}',
            '{C:inactive}(Currently: {}{C:blue}+#2#{}{C:inactive} chips){}'
        }
    },
    pos = {x = 4, y = 0},
    atlas = 'All_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 6, 
    rarity = 3,
    config = { extra = {
        chip_mod = 4, 
        chips = 0
    }
},
    loc_vars = function(self,info_queue,center)
        return {vars = {center.ability.extra.chip_mod,center.ability.extra.chips}} 
    end,

    calculate = function(self, card, context)
        if context.joker_main and card.ability.extra.chips > 0 then
            return {
                chips = card.ability.extra.chips
            }
        elseif context.before and next(context.poker_hands['Three of a Kind'])  and not context.blueprint then
            card.ability.extra.chips = card.ability.extra.chips + card.ability.extra.chip_mod
            return {
                message = localize('k_upgrade_ex'),
                card = card,
                colour = G.C.CHIPS
            }
        end
    end
}

SMODS.Joker{
    key = "karuta",
    loc_txt = {
        name = 'Karuta',
        text = 
        {
            '{C:green}Uncommon {}Jokers',
            ' each give{C:red} +#1# {}Mult',
        }
    },
    pos = {x = 8, y = 0},
    atlas = 'All_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 4, 
    rarity = 1,--cost
    config = { extra = {
        h_mult = 13
    }
},
    loc_vars = function(self,info_queue,center)
        return {vars = {center.ability.extra.h_mult}} 
    end,
    calculate = function(self, card, context)
        if context.other_joker then
            if context.other_joker.config.center.rarity == 2 and self ~= context.other_joker then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        context.other_joker:juice_up(0.5, 0.5)
                        return true
                    end
                })) 
                return {
                    mult_mod = card.ability.extra.h_mult,
                    message = '+' .. card.ability.extra.h_mult .. ' Mult',
                    colour = G.C.MULT
                }
            end
        end
    end
}


SMODS.Joker{
    key = "footballprint",
    loc_txt = {
        name = 'Football Print',
        text = 
        {
            '{C:green}#1# in #2#{} chance to',
            'gain {C:chips}+#4#{} Chips for',
            'every scoring card',
            '{C:inactive}(Current action: {C:chips}+#3#{C:inactive} chips)'

        }
    },
    pos = {x = 2, y = 1},
    atlas = 'All_jokers_atlas',
    blueprint_compat = true,
    unlocked = true, 
    discovered = false, 
    cost = 8, 
    rarity = 3,
    config = { extra = {
        chip_mod = 0,
        chip = 2,
        odds = 4
        
    }
},
    loc_vars = function(self,info_queue,center)
        return {vars = {G.GAME.probabilities.normal,center.ability.extra.odds,center.ability.extra.chip_mod,center.ability.extra.chip}}
    end,

    calculate = function(self,card,context)
        if pseudorandom('footballprint') < G.GAME.probabilities.normal/card.ability.extra.odds then
        if context.individual and context.cardarea == G.play and not context.blueprint then
            card.ability.extra.chip_mod = card.ability.extra.chip_mod + card.ability.extra.chip
            return {
                message = 'GOOOAL!!',
                colour = G.C.CHIPS,
            
            }
        end
    end
    
        if context.joker_main then
            return
            {
                chip_mod = card.ability.extra.chip_mod,
                message = '+' .. card.ability.extra.chip_mod,
                colour = G.C.CHIPS
            }
        end
    end

}

SMODS.Joker{
    key = "balanced",
    loc_txt = {
        name = 'Balanced',
        text = 
        {
            '{C:attention}+#1#{} Consumable slot'
        }
    },
    pos = {x = 7, y = 0},
    atlas = 'All_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = true,
    discovered = false, 
    cost = 5, 
    rarity = 1,
    config = { extra = {
        card_limit = 1
    }
},
    loc_vars = function(self,info_queue,center)
        return {vars = {center.ability.extra.card_limit}} 
    end,

    add_to_deck = function(self, card, from_debuff)
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            return true end }))
    end,

    remove_from_deck = function(self, card, from_debuff)
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            return true end }))
    end
}

SMODS.Joker{
    key = "drop",
    loc_txt = {
        name = 'Drop',
        text = 
        {
            'Retrigger all cards for',
            'the next {C:attention}#1#{} hands',
        }
    },
    pos = {x = 2, y = 0},
    atlas = 'All_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 5, 
    rarity = 1,--cost
    config = { extra = {
        retrigger_amt = 1,
        hands = 5
    }
},
    loc_vars = function(self,info_queue,center)
        return {vars = {center.ability.extra.hands}} 
    end,

    calculate = function(self,card,context)
        if context.repetition and context.cardarea == G.play then
            return
            {
                repetitions = card.ability.extra.retrigger_amt,
                card = card
            }     
        elseif context.after and not context.blueprint then
            card.ability.extra.hands = card.ability.extra.hands - 1
            if card.ability.extra.hands <= 0 then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound('tarot1')
                        card.T.r = -0.2
                        card:juice_up(0.3, 0.4)
                        card.states.drag.is = true
                        card.children.center.pinch.x = true
                        G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.3, blockable = false,
                            func = function()
                                    G.jokers:remove_card(card)
                                    card:remove()
                                    card = nil
                                return true; end})) 
                        return true
                    end
                }))
                return {
                    message = localize('k_eaten_ex'),
                    colour = G.C.RED
                }
            
        else
            return {
            message = localize {
            type = 'variable',
            key = 'a_remaining',
            vars = { card.ability.extra.hands }
          }
            }
        end
        end
    end
}


SMODS.Joker{
    key = "NFT",
    loc_txt = {
        name = 'Joker NFT',
        text = 
        {
            'Earn {C:attention}$#1#{}',
            'at {C:attention}setting blind{}',
            '{C:green}#2# in #3#{} chance this card',
            'is destroyed at',
            'the end of round',
            '{C:inactive}(Currently: {}{C:attention}$#4#{}{C:inactive}){}'
        }
    },
    pos = {x = 5, y = 3},
    atlas = 'All_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = true,
    discovered = false, 
    cost = 5, 
    rarity = 1,--cost
    config = { extra = {
        dollars = 0,
        increase = 1,
        odds = 5
    }
},
    loc_vars = function(self,info_queue,center)
        return {vars = {center.ability.extra.increase,G.GAME.probabilities.normal,center.ability.extra.odds,center.ability.extra.dollars}} 
    end,
    calculate = function(self, card, context)
        if context.setting_blind and not context.blueprint then 
            card.ability.extra.dollars = card.ability.extra.dollars + card.ability.extra.increase
            return {
                message = localize('k_upgrade_ex'),
                colour = G.C.MONEY
            }
        elseif context.end_of_round and not context.game_over and not context.blueprint and not context.individual and not context.repetition then
            if pseudorandom('NFT') < G.GAME.probabilities.normal/card.ability.extra.odds then
            G.E_MANAGER:add_event(Event{
                func = function()
                    play_sound('tarot1')
                    card.T.r = -0.2
                    card:juice_up(0.3, 0.4)
                    card.states.drag.is = true
                    card.children.center.pinch.x = true
                    G.E_MANAGER:add_event(Event{trigger = 'after', delay = 0.3, blockable = false,
                        func = function()
                            G.jokers:remove_card(card)
                            card:remove()
                            card = nil
                            return true
                        end
                    })
                    return true
                end
            })
            return
            {
                message = '-98% value'
            }
        else 
            return
            {
                message = localize('k_safe_ex')
            }
        end 
    end
end,

    in_pool = function(self,wawa,wawa2)
        --whether or not this card is in the pool, return true if it is, return false if its not
        return true
    end,
    calc_dollar_bonus = function(self,card)
        return card.ability.extra.dollars
        
    end,

}
SMODS.Joker{
    key = "TJ2",
    loc_txt = {
        name = 'Jester',
        text = 
        {
            '{C:blue}+#1#{} hand',
            '{C:attention}#2#{} hand size'
        }
    },
    pos = {x = 2, y = 2},
    atlas = 'New_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = true,
    discovered = false, 
    cost = 6, 
    rarity = 2,
    config = { extra =  {
        h_size = -2,
        hands = 1
    }
}, --cost

  set_ability = function(self, card, initial, delay_sprites)
    card.ability.h_size = card.ability.extra.h_size or 0
  end,
    loc_vars = function(self,info_queue,center)
        return {vars = {center.ability.extra.hands,center.ability.extra.h_size}} 
    end,
    calculate = function(self, card, context)
    if context.setting_blind then
		ease_hands_played(card.ability.extra.hands)
		return {
				message = '+1 hand',
				colour = G.C.BLUE
		}
    end
    end
}

SMODS.Joker{
    key = "TJ3",
    loc_txt = {
        name = 'Ridiculous bicycle',
        text = 
        {
            '{C:green}#1# in #2#{} posibilities to create',
            '{C:green}Uncommon{} joker with {C:dark_edition}perishable{} ',
            'when the {C:attention}blind is selected{}',
            '{C:inactive}(Must have room){}'
        }
    },
    pos = {x = 5, y = 2},
    atlas = 'New_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 6, 
    rarity = 2,
    config = { extra =  {
        odds = 6
    }
}, --cost

    loc_vars = function(self,info_queue,center)
        return {vars = {G.GAME.probabilities.normal,center.ability.extra.odds}} 
    end,
    calculate = function(self, card, context)
    if context.setting_blind and not (context.blueprint_card or self).getting_sliced and #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
         if pseudorandom('TJ3') < G.GAME.probabilities.normal/card.ability.extra.odds then
         G.E_MANAGER:add_event(Event {
          func = function()
            local c = SMODS.add_card {
              set = 'Joker',
              rarity = 'Uncommon',
              nil
            }
             c:add_sticker('perishable', true)
           
            return true
          end
        })
    else
        return {
            message = 'Maybe Not',
            card = card
        }
    end
end
end
}

SMODS.Joker{
    key = "TJ4",
    loc_txt = {
        name = 'Sake Cup',
        text = 
        {
            'If {C:attention}poker hand{} is',
            'a {C:attention}Straight Flush{}',
            'create a random {C:red}Rare{}',
            'joker with {C:dark_edition}perishable{}',
            '{C:inactive}(Must have room){}'
        }
    },
    pos = {x = 3, y = 2},
    atlas = 'New_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 6, 
    rarity = 2,
    config = { extra =  {
    }
}, --cost

    loc_vars = function(self,info_queue,center)
        return {vars = {center.ability.extra.h_mult}} 
    end,
    calculate = function(self, card, context)
    if context.before and next(context.poker_hands['Straight Flush']) then
        G.E_MANAGER:add_event(Event {
          func = function()
            local c = SMODS.add_card {
              set = 'Joker',
              rarity = 'Rare',
              nil
            }
             c:add_sticker('perishable', true)
           
            return true
          end
        })
        return {
				message = 'Koi Koi',
				colour = G.C.MULT
		}
    end
    end
}

SMODS.Joker{
    key = "TJ5",
    loc_txt = {
        name = 'Eugine',
        text = 
        {
            'Add a {C:attention}free{} {C:tarot}Arcana pack{}',
            'to the {C:attention}shop{}'
        }
    },
    pos = {x = 4, y = 2},
    atlas = 'New_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = true,
    discovered = false, 
    cost = 8, 
    rarity = 3,
    config = { extra =  {
    }
}, --cost

    loc_vars = function(self,info_queue,center)
        return {vars = {center.ability.extra.h_mult}} 
    end,
    calculate = function(self, card, context)
    if context.starting_shop then
      G.E_MANAGER:add_event(Event {
        func = function()
          local key = 'p_arcana_normal_' .. pseudorandom('TJ5', 1, 2)
          local booster = SMODS.add_booster_to_shop(key)
          booster.ability.couponed = true
          booster:set_cost()
          return true
        end
      })
    end
    end
}

SMODS.Joker{
    key = "TJ6",
    loc_txt = {
        name = 'Cardboard Joker',
        text = 
        {
            'The {C:attention}Cardboard{} cards loses',
            'their {C:blue}chips{} when scored',
            'This Joker gains {C:red}mult{} equal',
            'to {C:attention}half their value{}',
            '{C:inactive}(Current action: {}{C:mult}+#1#{}{C:inactive} mult){}'
        }
    },
    pos = {x = 0, y = 2},
    atlas = 'New_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 7, 
    rarity = 2,
    config = { extra =  {
        h_mult = 0,
        min_bonus = 0
    }
}, --cost

    loc_vars = function(self,info_queue,center)
        info_queue[#info_queue+1] = G.P_CENTERS.m_abstract_cardboard
        return {vars = {center.ability.extra.h_mult}} 
    end,
    calculate = function(self, card, context)     
    if context.cardarea == G.play and context.individual and not context.blueprint and SMODS.get_enhancements(context.other_card)["m_abstract_cardboard"]  then    
        card.ability.extra.min_bonus = 0
        context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus or 0
        card.ability.extra.min_bonus = context.other_card.base.nominal * -1
        if context.other_card.ability.perma_bonus > card.ability.extra.min_bonus then
            local thunk = context.other_card.ability.perma_bonus
            context.other_card.ability.perma_bonus = math.max((context.other_card.ability.perma_bonus - context.other_card.base.nominal), (card.ability.extra.min_bonus))
            thunk = thunk - context.other_card.ability.perma_bonus
            card.ability.extra.h_mult = card.ability.extra.h_mult + (thunk / 2)
            return {
                    extra = {message = localize('k_eaten_ex'), colour = G.C.CHIPS},
                    colour = G.C.CHIPS,
                    card = card
            }
        end

    elseif context.joker_main and card.ability.extra.h_mult > 0 then
            return {
                    mult_mod = card.ability.extra.h_mult,
                    message = '+' .. card.ability.extra.h_mult .. ' Mult',
                    colour = G.C.MULT
            }

    end

    end
}

SMODS.Joker{
    key = "TJ7",
    loc_txt = {
        name = 'Ceramic joker',
        text = 
        {
            '{X:chips,C:white}X#1#{} Chips to a',
            '{C:attention}Bonus{} or {C:attention}Stone{} cards',
            'when scored'
        }
    },
    pos = {x = 8, y = 1},
    atlas = 'New_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 8, 
    rarity = 3,
    config = { extra =  {
        xchips = 1.5,
    }
}, 

    loc_vars = function(self,info_queue,center)
        info_queue[#info_queue+1] = G.P_CENTERS.m_bonus
        info_queue[#info_queue+1] = G.P_CENTERS.m_stone
        return {vars = {center.ability.extra.xchips,}} 
    end,
    calculate = function(self, card, context) 

    if not card.debuff then
      if context.individual and context.cardarea == G.play then
        if SMODS.get_enhancements(context.other_card)["m_bonus"] == true or SMODS.get_enhancements(context.other_card)["m_stone"] then
          return {
            xchips = card.ability.extra.xchips,
            colour = G.C.CHIPS,
            card = card
          }
        end
      end
    end

    end
}
SMODS.Joker{
    key = "TJ9",
    loc_txt = {
        name = 'Flower Viewing Curtain',
        text = 
        {
            'All {C:attention}Face{} cards',
            'become {C:attention}Hanafuda{}',
            'cards when scored',
        }
    },
    pos = {x = 9, y = 1},
    atlas = 'New_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = true,
    discovered = false, 
    cost = 6, 
    rarity = 2,
    config = { extra =  {
    }
}, --cost

    loc_vars = function(self,info_queue,center)
        info_queue[#info_queue+1] = G.P_CENTERS.m_abstract_hanafuda
        return {vars = {center.ability.extra.h_mult}} 
    end,
    calculate = function(self, card, context)    

        if context.cardarea == G.jokers and context.before and not context.blueprint then
			local has_face = false
            for k, v in ipairs(context.scoring_hand) do
				if v:is_face() then 
					has_face = true
					v:set_ability(G.P_CENTERS.m_abstract_hanafuda,nil,true)
					G.E_MANAGER:add_event(Event({
						func = function()
							v:juice_up()
							return true
						end
					}))
				end
			end
			if has_face then
				return {
					message = 'Yaku',
					colour = G.C.MULT,
					card = card,
				}
			end
		end

    end
}

SMODS.Joker{
    key = "TJ11",
    loc_txt = {
        name = 'Plantain',
        text = 
        {
            '{X:chips,C:white}X#1#{} chips',
            '{C:green}#2# in #3#{} chance this',
            'card is destroyed',
            'at end of round'
        }
    },
    pos = {x = 6, y = 2},
    atlas = 'New_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 5, 
    rarity = 1,
    pools = {
        Food = true
    },
    config = { extra =  {
        x_chips = 1.5,
        odds = 5,
    }
}, --cost

    loc_vars = function(self,info_queue,center)
        return {vars = {center.ability.extra.x_chips,G.GAME.probabilities.normal,center.ability.extra.odds}} 
    end,
    calculate = function(self, card, context)
    if context.joker_main then
      return {
        x_chips = card.ability.extra.x_chips
      }
    end
     if context.end_of_round and not context.blueprint and context.main_eval then
      if pseudorandom('TJ11') < G.GAME.probabilities.normal/card.ability.extra.odds then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound('tarot1')
                        card.T.r = -0.2
                        card:juice_up(0.3, 0.4)
                        card.states.drag.is = true
                        card.children.center.pinch.x = true
                        G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.3, blockable = false,
                            func = function()
                                    G.jokers:remove_card(card)
                                    card:remove()
                                    card = nil
                                return true; end})) 
                        return true
                    end
                }))

        return {
          message = localize('k_eaten_ex'),
          colour = G.C.CHIPS,
          card = card
        }
      else
        return {
          message = localize('k_safe_ex'),
          colour = G.C.CHIPS,
          card = card
        }
      end
    end
    end
}

SMODS.Joker{
    key = "TJ13",
    loc_txt = {
        name = 'Villar planets',
        text = 
        {
                "This Joker gains {X:chips,C:white}X#1#{} chips",
                "every {C:attention}#2#{} {C:inactive}[#3#]{} {C:planet}planet{} cards used",
                "{C:inactive}(Currently:{} {X:chips,C:white}X#4#{} {C:inactive}chips){}",
        }
    },
    pos = {x = 7, y = 2},
    atlas = 'New_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 7, 
    rarity = 2,
    config = { extra =  {
        xchips = 1,
        gain = 0.20,
        remaining = 9,
        used = 9
    }
}, --cost

    loc_vars = function(self,info_queue,center)
        return { vars = {center.ability.extra.gain, center.ability.extra.used, center.ability.extra.remaining, center.ability.extra.xchips } }
    end,
calculate = function(self, card, context)

        if context.joker_main and card.ability.extra.xchips > 0 then
            return {
                xchips = card.ability.extra.xchips,
            }
        elseif context.using_consumeable then
            if context.consumeable.ability.set == 'Planet' and not context.blueprint then
            -- receives this context for every discarded card individually
            if card.ability.extra.remaining <= 1 then
                card.ability.extra.remaining = card.ability.extra.used
                card.ability.extra.xchips = card.ability.extra.xchips + card.ability.extra.gain
                return {
                    message = localize('k_upgrade_ex'),
                }
            else
                card.ability.extra.remaining = card.ability.extra.remaining - 1
            end
        end
        end

end
}

SMODS.Joker{
    key = "TJ14",
    loc_txt = {
        name = 'Full Moon',
        text = 
        {
                'Creates a {C:dark_edition}Negative{} copy',
                'of {C:attention}1{} random {C:attention}consumable{}',
                'card in your possession',
                'every {C:attention}#2#{} {C:inactive}[#3#]{} {C:attention}consumable{} used',
        }
    },
    pos = {x = 9, y = 2},
    atlas = 'New_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = true,
    discovered = false, 
    cost = 7, 
    rarity = 2,
    config = { extra =  {
        remaining = 7,
        used = 7

    }
}, --cost

    loc_vars = function(self,info_queue,center)
        return { vars = {center.ability.extra.gain, center.ability.extra.used, center.ability.extra.remaining } }
    end,
calculate = function(self, card, context)
    if context.using_consumeable and not context.blueprint then
            if card.ability.extra.remaining <= 1 then
                card.ability.extra.remaining = card.ability.extra.used
                 if G.consumeables.cards[1] then
                    G.E_MANAGER:add_event(Event({
                        func = function() 
                            local card = copy_card(pseudorandom_element(G.consumeables.cards, pseudoseed('TJ14')), nil)
                            card:set_edition({negative = true}, true)
                            card:add_to_deck()
                            G.consumeables:emplace(card) 
                            return true
                        end}))
                    return {
                        message = localize('k_duplicated_ex')
                    }
                end
            else
                card.ability.extra.remaining = card.ability.extra.remaining - 1
            end
        
    end

end
}

SMODS.Joker{
    key = "TJ15",
    loc_txt = {
        name = 'Slay the Joker',
        text = 
        {
                "{C:attention}+#1#{} joker slot",
                "{C:chips}#2#{} hand"
        }
    },
    pos = {x = 8, y = 2},
    atlas = 'New_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = true,
    discovered = false, 
    cost = 7, 
    rarity = 2,
    config = { extra =  {
        card_limit = 1,
        h_plays = -1
    }
}, --cost

    loc_vars = function(self,info_queue,center)
        return { vars = {center.ability.extra.card_limit,center.ability.extra.h_plays} }
    end,

    add_to_deck = function(self, card, from_debuff)
        G.E_MANAGER:add_event(Event({func = function()
            G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.card_limit
            G.GAME.round_resets.hands = G.GAME.round_resets.hands + card.ability.extra.h_plays
            return true end }))
    end,

    remove_from_deck = function(self, card, from_debuff)
        G.E_MANAGER:add_event(Event({func = function()
            G.jokers.config.card_limit = G.jokers.config.card_limit - card.ability.extra.card_limit
            G.GAME.round_resets.hands = G.GAME.round_resets.hands - card.ability.extra.h_plays
            return true end }))
    end
}


SMODS.Joker{
    key = "TJ16",
    loc_txt = {
        name = 'Poptart',
        text = 
        {
            'For the next {C:attention}#1#{} hands',
            'Balance {C:blue}Chips{} and {C:red}Mult{}',
        }
    },
    pos = {x = 1, y = 2},
    atlas = 'New_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 8, 
    rarity = 3,
    config = { extra =  {
        hands = 5

    }
},

    loc_vars = function(self,info_queue,center)
        return { vars = {center.ability.extra.hands } }
    end,
calculate = function(self, card, context)

    if context.joker_main then
            return {
                balance = true
            }
        end

    if context.after and not context.blueprint then
        card.ability.extra.hands = card.ability.extra.hands - 1
            if card.ability.extra.hands <= 0 then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound('tarot1')
                        card.T.r = -0.2
                        card:juice_up(0.3, 0.4)
                        card.states.drag.is = true
                        card.children.center.pinch.x = true
                        G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.3, blockable = false,
                            func = function()
                                    G.jokers:remove_card(card)
                                    card:remove()
                                    card = nil
                                return true; end})) 
                        return true
                    end
                }))
                return {
                    message = localize('k_eaten_ex'),
                    colour = G.C.RED
                }
        else
            return {
            message = localize {
            type = 'variable',
            key = 'a_remaining',
            vars = { card.ability.extra.hands }
          }
            }
        end
    end
end
}

SMODS.Joker{
    key = "TJ17",
    loc_txt = {
        name = 'Rules Card',
        text = 
        {
            '{C:attention}+1{} card selection limit'
        }
    },
    pos = {x = 3, y = 0},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = true,
    discovered = false, 
    cost = 6, 
    rarity = 1,
    config = { extra =  {
    }
}, --cost

    loc_vars = function(self,info_queue,center)
        return { vars = {center.ability.extra.card_limit,center.ability.extra.h_plays} }
    end,

    add_to_deck = function(self, card, from_debuff)
		SMODS.change_play_limit(1)
		SMODS.change_discard_limit(1)
	end,
	remove_from_deck = function(self, card, from_debuff)
		SMODS.change_play_limit(-1)
		SMODS.change_discard_limit(-1)
	end,
}

SMODS.Joker{
    key = "TJ18",
    loc_txt = {
        name = 'Spindown Dice',
        text = 
        {
            'Add {C:green}#1#{} all {C:attention}listed{} {C:green}probabilities{}',
            'reduces by {C:red}1{} in end of the round',
            '(ex: {C:green}1 in 3{} -> {C:green}#1# in 3{})',
            
        }
    },
     pos = {x = 0, y = 1},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = true,
    discovered = false, 
    cost = 6, 
    rarity = 2,
    config = { extra =  {
        odds = 4,
        o_mod = 1
    }
}, --cost

loc_vars = function(self,info_queue,center)
    return {vars = {center.ability.extra.odds}} --#1# is replaced with card.ability.extra.Xmult
end,

remove_from_deck = function(self, card, from_debuff)
	for k, v in pairs(G.GAME.probabilities) do
		G.GAME.probabilities[k] = v/card.ability.extra.odds
	end
end,

calculate = function(self,card,context)
 for k, v in pairs(G.GAME.probabilities) do
		G.GAME.probabilities[k] = card.ability.extra.odds
	end
if context.end_of_round and not context.game_over and not context.blueprint and not context.individual and not context.repetition then
        card.ability.extra.odds = card.ability.extra.odds - 1
            if card.ability.extra.odds <= 0 then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound('tarot1')
                        card.T.r = -0.2
                        card:juice_up(0.3, 0.4)
                        card.states.drag.is = true
                        card.children.center.pinch.x = true
                        G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.3, blockable = false,
                            func = function()
                                    G.jokers:remove_card(card)
                                    card:remove()
                                    card = nil
                                return true; end})) 
                        return true
                    end
                }))
                return {
                    message = '-1',
                    colour = G.C.RED
                }
        else
            return {
            message = localize {
            type = 'variable',
            key = 'a_remaining',
            vars = { card.ability.extra.odds }
          }
            }
        end
    end
end
}
SMODS.Joker{
    key = "D2",
    loc_txt = {
        name = 'Oh no...',
        text = 
        {
            '{C:green}Randomize{} all {C:attention}listed{}',
            '{C:green}probabilities{} in {C:attention}setting blind{}',
            '{C:inactive}(Currently:{} {C:green}#1#{} {C:inactive}odds){}'
            
        }
    },
    pos = {x = 5, y = 1},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = true,
    discovered = false, 
    cost = 7, 
    rarity = 2,
    config = { extra =  {
        min = 1,
        max = 6,
        odds = 0
    }
}, 
loc_vars = function(self,info_queue,center)
    return {vars = {center.ability.extra.odds}}
end,

remove_from_deck = function(self, card, from_debuff)
	for k, v in pairs(G.GAME.probabilities) do
		G.GAME.probabilities[k] = v/card.ability.extra.odds
	end
end,

calculate = function(self,card,context)
if context.setting_blind and not context.blueprint then
    local temp_odds = pseudorandom(pseudoseed('D2'), card.ability.extra.min, card.ability.extra.max)
    for k, v in pairs(G.GAME.probabilities) do
		G.GAME.probabilities[k] = temp_odds
	end
    card.ability.extra.odds = temp_odds
    return {
        message = 'Oh no, its...'.. temp_odds
    }
end

if context.end_of_round and context.main_eval and not context.blueprint then
    for k, v in pairs(G.GAME.probabilities) do 
           	G.GAME.probabilities[k] = v/card.ability.extra.odds
    end
    card.ability.extra.odds = 0
    return {
        message = 'Reset'
    }
end


end
}

SMODS.Joker{
    key = "TJ27",
    loc_txt = {
        name = 'Cesar Salad',
        text = 
        {
            'This joker gains {C:chips}+#1#{} chips',
            'every {C:attention}#2#{} {C:inactive}[#3#]{} cards discarded',   
            '{C:inactive}(Currently:{}{C:chips} +#4#{C:inactive} Chips)'
        }
    },
     pos = {x = 3, y = 1},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 6, 
    rarity = 1,
    config = { extra =  {
        discards = 23, 
        discards_remaining = 23,
        gain = 9,
        chips = 0

    }
},

loc_vars = function(self,info_queue,center)
    return {vars = {center.ability.extra.gain, center.ability.extra.discards, center.ability.extra.discards_remaining, center.ability.extra.chips }} 
end,


calculate = function(self, card, context)
	 if context.discard and not context.blueprint then
            -- receives this context for every discarded card individually
            if card.ability.extra.discards_remaining <= 1 then
                card.ability.extra.discards_remaining = card.ability.extra.discards
                card.ability.extra.chips = card.ability.extra.chips + card.ability.extra.gain
                return {
                    message = localize('k_upgrade_ex'),
                }
            else
                card.ability.extra.discards_remaining = card.ability.extra.discards_remaining - 1
            end
        end

         if context.joker_main then
            return {
                chip_mod = card.ability.extra.chips ,
                message = '+' .. card.ability.extra.chips .. 'Chips' ,
                colour = G.C.CHIPS,
                card = card
            }
        end
end
}

SMODS.Joker{
    key = "TJ30",
    loc_txt = {
        name = 'Black Queen',
        text = 
        {
            '{C:chips}+#1#{} chips for',
            'every {C:attention}5{} or {C:attention}7{}',   
            'when scored'
        }
    },
    pos = {x = 1, y = 0},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 4, 
    rarity = 1,
    config = { extra =  {
        chips = 30

    }
},

loc_vars = function(self,info_queue,center)
    return {vars = {center.ability.extra.chips}} 
end,


calculate = function(self, card, context)
	 if context.individual and context.cardarea == G.play and (context.other_card:get_id() == 5 or context.other_card:get_id() == 7) then
        return
        {
        chip_mod = card.ability.extra.chips,
        message = '+' .. card.ability.extra.chips ,
        colour = G.C.CHIPS,
        card = card
        }
     end
end
}

SMODS.Joker{
    key = "TJ31",
    loc_txt = {
        name = 'Enchre',
        text = 
        {
            '{X:mult,C:white}X#1#{} mult',
            'if {C:attention}poker hand{} contains',   
            'a {C:attention}Flush{} and {C:attention}Jack{}'
        }
    },
    pos = {x = 2, y = 0},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 4, 
    rarity = 1,
    config = { extra =  {
        Xmult = 2
    }
},

loc_vars = function(self,info_queue,center)
    return {vars = {center.ability.extra.Xmult}} 
end,


calculate = function(self, card, context)
      if context.joker_main then
            local contains = false
            if context.full_hand and #context.full_hand > 0 then
                for _, _card in ipairs(context.full_hand) do
                    if _card:get_id() == 11 
                    then
                        contains = true
                        break 
                    end
                end
            else
            end

            if contains and context.scoring_name == 'Flush' then
                return {
                    Xmult_mod = card.ability.extra.Xmult,
                    message = 'X' .. card.ability.extra.Xmult .. ' Mult',
                    colour = G.C.MULT,
                    card = card
                }
            end
        end
        return nil
    end
}

SMODS.Joker{
    key = "TJ36",
    loc_txt = {
        name = 'Balloon',
        text = 
        {
            
            '{C:blue}+#2#{} chips per hand played',   
            '{C:green}#3# in #4#{} chance to destroy',
            'end of round',
            '{C:inactive}(Currently: {}{C:blue}+#1#{}{C:inactive} chips){}'
        }
    },
    pos = {x = 5, y = 0},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 4, 
    rarity = 1,
    config = { extra =  {
        chips = 0,
        gain = 5,
        odds = 6 

    }
},

loc_vars = function(self,info_queue,center)
    return {vars = {center.ability.extra.chips,center.ability.extra.gain,G.GAME.probabilities.normal,center.ability.extra.odds}} 
end,


calculate = function(self, card, context)
    if context.before and context.main_eval and not context.blueprint then
            card.ability.extra.chips = card.ability.extra.chips + card.ability.extra.gain
            return {
                message = '+'.. card.ability.extra.gain .. ' Chips',
                card = card,
                colour = G.C.CHIPS
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval and not context.blueprint then
            if pseudorandom('TJ36') < G.GAME.probabilities.normal / card.ability.extra.odds then
                    G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound('tarot1')
                        card.T.r = -0.2
                        card:juice_up(0.3, 0.4)
                        card.states.drag.is = true
                        card.children.center.pinch.x = true
                        G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.3, blockable = false,
                            func = function()
                                    G.jokers:remove_card(card)
                                    card:remove()
                                    card = nil
                                return true; end})) 
                        return true
                    end
                }))
                return {
                    message = 'Pop!',
                    colour = G.C.RED
                }
                else
                return {
                    message = localize('k_safe_ex')
                }
            end
        end
        if context.joker_main then
                return {
                    chip_mod = card.ability.extra.chips,
                   message = '+' .. card.ability.extra.chips .. ' Chips',
                }
        end

end
}

SMODS.Joker{
    key = "TJ38",
    loc_txt = {
        name = 'Matrioskas',
        text = 
        {
            'This Joker gains {X:mult,C:white}X#1#{} Mult',
            'when {C:attention}Straight{} is discarded',   
            '{C:inactive}(Currently: {}{X:mult,C:white}X#2#{}{C:inactive} mult){}'

        }
    },
    pos = {x = 2, y = 1},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 4, 
    rarity = 3,
    config = { extra =  {

        xmult= 1,
        gain = 0.2


    }
},

loc_vars = function(self,info_queue,center)
    return {vars = {center.ability.extra.gain,center.ability.extra.xmult}} 
end,


calculate = function(self, card, context)
    if context.pre_discard then
        if not context.blueprint then
            if G.hand and G.hand.highlighted and #G.hand.highlighted > 0 then
                local hand_info = G.FUNCS.get_poker_hand_info(G.hand.highlighted)
                if hand_info == 'Straight' or hand_info == 'Straight Flush'  or hand_info == 'Royal Flush' then
                    card.ability.extra.xmult = card.ability.extra.xmult + card.ability.extra.gain

                    card_eval_status_text(card, 'extra', nil, nil, nil, {
                        message = 'X'..number_format(card.ability.extra.xmult).. ' Mult',
                        colour = G.C.MULT
                    })

                    return nil, true
                end
            end
        end
    end
     if context.joker_main then
        if card.ability.extra.xmult > 1 then
            return {
                xmult = card.ability.extra.xmult,
            }
        end
    end
end
}

SMODS.Joker{
    key = "TJ39",
    loc_txt = {
        name = 'Gillotiona',
        text = 
        {
            'This Joker gains {C:red}+#1#{} Mult',
            'when a {C:attention}face card{} is destroyed',   
            '{C:inactive}(Currently: {}{C:red}+#2#{}{C:inactive} mult){}'

        }
    },
    pos = {x = 6, y = 0},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 4, 
    rarity = 1,
    config = { extra =  {
        mult = 0,
        gain = 2
    }
},

loc_vars = function(self,info_queue,center)
    return {vars = {center.ability.extra.gain,center.ability.extra.mult}} 
end,


calculate = function(self, card, context)
    if (context.remove_playing_cards or context.cards_destroyed) and not context.blueprint then
      local remove = context.glass_shattered or context.removed
      local face_cards = 0
      for k, val in ipairs(remove) do
        if val:is_face() then face_cards = face_cards + 1 end
      end
      for _ = 1, face_cards do
        card.ability.extra.mult = card.ability.extra.mult + (face_cards * card.ability.extra.gain)
        return {
          message = '+' .. card.ability.extra.mult .. ' Mult',
          colour = G.C.RED
        }
      end
      return
    end
    if context.joker_main then
      return {
        mult = card.ability.extra.mult,
      }
    end
end
}

SMODS.Joker{
    key = "TJ40",
    loc_txt = {
        name = 'Gold nugget',
        text = 
        {
            'This Joker gains {C:blue}+#1#{} chips',
            'per scoring {C:attention}Stone card{} played,',
            'removes card {C:attention}Enhancement{}',   
            '{C:green}#3# in #4#{} chance to add',
            '{C:attention}Gold{} Enhancement',
            '{C:inactive}(Currently: {}{C:blue}+#2#{}{C:inactive} chips){}'

        }
    },
    pos = {x = 7, y = 0},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 7, 
    rarity = 3,
    config = { extra =  {
        chips = 0,
        gain = 8,
        odds = 5

    }
},

loc_vars = function(self,info_queue,center)
    info_queue[#info_queue+1] = G.P_CENTERS.m_stone
    info_queue[#info_queue+1] = G.P_CENTERS.m_gold
    return {vars = {center.ability.extra.gain,center.ability.extra.chips,G.GAME.probabilities.normal,center.ability.extra.odds}} 
end,


calculate = function(self, card, context)

     if context.cardarea == G.jokers and context.before and not context.blueprint then
			local message = false
            for k, v in ipairs(context.scoring_hand) do
                if SMODS.has_enhancement(v,'m_stone') then
                    card.ability.extra.chips = card.ability.extra.chips + card.ability.extra.gain
                    message = true
                    if pseudorandom('TJ40') < G.GAME.probabilities.normal/card.ability.extra.odds then
                    v:set_ability(G.P_CENTERS.m_gold, nil, true)
                    else
					v:set_ability(G.P_CENTERS.c_base,nil,true)
                    end
					G.E_MANAGER:add_event(Event({
						func = function()
							v:juice_up()
							return true
						end
					}))
                end
			end
			if message then
				return {
					message = localize('k_upgrade_ex'),
					colour = G.C.MULT,
					card = card,
				}
			end
		end
         if context.joker_main and card.ability.extra.chips > 0 then
            return {
                chips = card.ability.extra.chips,
            }
        end
   
end
}

SMODS.Joker{
    key = "TJ43",
    loc_txt = {
        name = 'The first',
        text = 
        {
            'After {C:attention}#2#{} rounds',
            'Sell this card and {C:red}reduce{} a ',
            '{C:attention}Blind requirement{} by {C:attention}25%{}',
            '{C:inactive}(Currently:{} {C:attention}#1#{}{C:inactive}/#2#){}'

        }
    },
    pos = {x = 6, y = 1},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = false,
    discovered = false, 
    cost = 4, 
    rarity = 2,
    config = { extra =  {
        current = 0,
        rounds = 2
    }
},

loc_vars = function(self,info_queue,center)
    return {vars = {center.ability.extra.current,center.ability.extra.rounds}} 
end,


calculate = function(self, card, context)
     if context.selling_self and G.GAME.blind and (card.ability.extra.current >= card.ability.extra.rounds) and not context.blueprint then
        G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.4,func = function()
                G.GAME.blind.chips = math.floor(G.GAME.blind.chips * 0.60)
                G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)

                local chips_UI = G.hand_text_area.blind_chips
                G.FUNCS.blind_chip_UI_scale(G.hand_text_area.blind_chips)
                G.HUD_blind:recalculate() 
                chips_UI:juice_up()
            
                if not silent then play_sound('chips2') end
                return true end }))
        end

    if context.end_of_round and context.game_over == false and context.main_eval and not context.blueprint then
      card.ability.extra.current = card.ability.extra.current + 1
      if card.ability.extra.current == card.ability.extra.rounds then
        local eval = function(card) return not card.REMOVED end
        juice_card_until(card, eval, true)
      end
      return {
        message = card.ability.extra.current .. '/' .. card.ability.extra.rounds,
        colour = G.C.BLUE
      }
    end
end
}

SMODS.Joker{
    key = "TJ50",
    loc_txt = {
        name = 'Lake Skip',
        text = 
        {
            'Retrigger {C:attention}2{} additonal times' ,
            'the {C:attention}first{} and {C:attention}last{} card',
            'when score'

        }
    },
    pos = {x = 4, y = 1},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 6, 
    rarity = 2,
    config = { extra =  {

    }
},

loc_vars = function(self,info_queue,center)
    return {vars = {center.ability.extra.remaining,center.ability.extra.used}} 
end,


calculate = function(self, card, context)
    if not card.debuff then
      if context.repetition and context.cardarea == G.play then
        if context.other_card == context.scoring_hand[1] or context.other_card == context.scoring_hand[#context.scoring_hand] then
          return {
            message = localize('k_again_ex'),
            repetitions = 2,
            card = card
          }
        end
      end
    end

end
}

SMODS.Joker{
    key = "TJ51",
    loc_txt = {
        name = 'Geisha',
        text = 
        {
            'This Joker adds the same effects',
            'as {C:attention}Lucky Cards{} to {C:attention}Hanafuda cards{}',
            'when score'
        }
    },
    pos = {x = 4, y = 0},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = true,
    discovered = false, 
    cost = 7, 
    rarity = 2,
    config = { extra =  {
        odds = 5,
        extra_odds = 15,
        mult = 20,
        money = 20
    }
},

loc_vars = function(self,info_queue,center)
    info_queue[#info_queue+1] = G.P_CENTERS.m_lucky
    info_queue[#info_queue+1] = G.P_CENTERS.m_abstract_hanafuda
end,


calculate = function(self, card, context)
if context.individual and context.cardarea == G.play and not context.blueprint and SMODS.get_enhancements(context.other_card)["m_abstract_hanafuda"] then
    if pseudorandom('TJ51') < G.GAME.probabilities.normal/card.ability.extra.odds then
        return
        {
            card = card,
            mult_mod = card.ability.extra.mult,
            message = '+' .. card.ability.extra.mult .. ' Mult',
            colour = G.C.MULT
        }
     else if pseudorandom('TJ51') < G.GAME.probabilities.normal/card.ability.extra.extra_odds then
         G.GAME.dollar_buffer = (G.GAME.dollar_buffer or 0) + 2
            G.E_MANAGER:add_event(Event({func = (function() G.GAME.dollar_buffer = 0; return true end)}))
            return {
                dollars = card.ability.extra.money,
                card = card
            }
        end
    end
end
end
}

SMODS.Joker{
    key = "TJ52",
    loc_txt = {
        name = 'Damocles',
        text = 
        {
            'All costs {C:attention}$#3#{} less in the shop',
            '{C:green}#1# in #2#{} chance to set the',
            '{C:blue}hands{} by {C:red}1{} in ',
            'the start for the round',
        }
    },
    pos = {x = 1, y = 1},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = true,
    discovered = false, 
    cost = 7,
    rarity = 2,
    config = { extra =  {
        odds = 1,
        inflation = 2,
        hands = 1,
        

    }
},

loc_vars = function(self,info_queue,center)
   return {vars = {G.GAME.probabilities.normal,center.ability.extra.odds,center.ability.extra.inflation}} 
end,

   add_to_deck = function(self, card, from_debuff)
        G.GAME.inflation = G.GAME.inflation - card.ability.extra.inflation
        for k, v in pairs(G.I.CARD) do
            if v.set_cost then
                v:set_cost()
            end
        end
    end,
    remove_from_deck = function(self, card, from_debuff)
        G.GAME.inflation = G.GAME.inflation + card.ability.extra.inflation
        for k, v in pairs(G.I.CARD) do
            if v.set_cost then
                v:set_cost()
            end
        end
    end,

    

calculate = function(self, card, context) 
      if context.setting_blind and not context.blueprint  then
         if pseudorandom('TJ52') < G.GAME.probabilities.normal/card.ability.extra.odds then
            if not context.blueprint and not context.retrigger_joker then ease_hands_played(-1 * (G.GAME.round_resets.hands - card.ability.extra.hands)) end
			return {
				message = "Opps...",
				colour = G.C.BLUE
			}
    else
        return {
            message = 'Maybe Not',
            card = card
        }
    end
end
end
}

SMODS.Joker{
    key = "TJ54",
    loc_txt = {
        name = 'Amazonita',
        text = 
        {
            'The {C:attention}Stone Cards{}',
            'held in the hand',
            'count of the puntuation',
        }
    },
    pos = {x = 2, y = 2},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 8, 
    rarity = 2,
    config = { extra =  {
    }
},
loc_vars = function(self,info_queue,center)
    info_queue[#info_queue+1] = G.P_CENTERS.m_stone
end,
calculate = function(self, card, context) 
       if not context.end_of_round and context.individual and context.cardarea == G.hand and SMODS.get_enhancements(context.other_card)["m_stone"] then
                    return {
                        card = card,
                        chips = context.other_card:get_chip_bonus()
                    }
                end
            end
}

SMODS.Joker{
    key = "TJ58",
    loc_txt = {
        name = 'YinYang',
        text = 
        {
            'Each played {C:attention}#1#{} of {C:clubs}Clubs{} or {C:hearts}Hearts{}',
            'gives {X:mult,C:white}X#2# {} Mult when scored,',
            'rank changes every round'
        }
    },
    pos = {x = 0, y = 2},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 6, 
    rarity = 2,
    config = { extra =  {
        rank = 'Jack',
        Xmult = 2

    }
},
loc_vars = function(self,info_queue,center)
   return {vars = {localize(center.ability.extra.rank, 'ranks'),center.ability.extra.Xmult}} 
end,
 set_ability = function(self, card)
        if G.playing_cards and #G.playing_cards > 0 then
            card.ability.extra.rank = pseudorandom_element(G.playing_cards, pseudoseed('TJ58')).base.value
        end
    end,
calculate = function(self, card, context) 
    if context.end_of_round and context.main_eval and not context.blueprint then
            card.ability.extra.rank = pseudorandom_element(G.playing_cards, pseudoseed('TJ58')).base.value
            return {
                no_retrigger = true
            }
    end
    if context.cardarea == G.play and context.individual and context.other_card.base.value == card.ability.extra.rank and (context.other_card:is_suit("Clubs") or context.other_card:is_suit("Hearts")) then
        return {
            card = card,
            Xmult_mod = card.ability.extra.Xmult,
            message = 'X' .. card.ability.extra.Xmult .. ' Mult',
            colour = G.C.MULT
         }
    end


end

}
SMODS.Joker{
    key = "TJ56",
    loc_txt = {
        name = 'Chula-Reh',
        text = 
        {
            'Add {C:green}1{} all {C:attention}listed{}',
            '{C:green}probabilities{} in setting blind',
            '{C:green}#1# in #2#{} chance to reset',
            '{C:inactive}(Currently: {}{C:green}+#3#{} {C:inactive}odds){}',
            '{C:inactive}(The odds no afect this joker){}'
        }
    },
    pos = {x = 1, y = 2},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = true,
    discovered = false, 
    cost = 8, 
    rarity = 3,
    config = { extra =  {
        j_odds = 1,
        odds = 5,
        gain = 1,
        o_mod = 1
    }
},
loc_vars = function(self,info_queue,center)
   return {vars = {center.ability.extra.j_odds,center.ability.extra.odds,center.ability.extra.o_mod}} 
end,
remove_from_deck = function(self, card, from_debuff)
	for k, v in pairs(G.GAME.probabilities) do
		G.GAME.probabilities[k] = v/card.ability.extra.o_mod
	end
end,

calculate = function(self, card, context) 
    if context.setting_blind and not context.blueprint then
        if pseudorandom('TJ56') < card.ability.extra.j_odds/card.ability.extra.odds then
        for k, v in pairs(G.GAME.probabilities) do
		G.GAME.probabilities[k] = card.ability.extra.o_mod / card.ability.extra.o_mod 
        end
        card.ability.extra.o_mod = card.ability.extra.o_mod / card.ability.extra.o_mod 
        return {
            message = 'Reset',
            card = card,
            colour = G.C.CHIPS

        }
    else
    for k, v in pairs(G.GAME.probabilities) do
		G.GAME.probabilities[k] = card.ability.extra.o_mod + 1
	end
       card.ability.extra.o_mod = card.ability.extra.o_mod + 1
         return {
                message = localize('k_upgrade_ex'),
                card = card,
                colour = G.C.CHIPS
            }
    end
end
end

}

SMODS.Joker{
    key = "TJ60",
    loc_txt = {
        name = 'Inscryption',
        text = 
        {   
            'After {C:attention}#2#{} rounds',
            'Sell this card and',
            'Replaces all held {C:attention}consumables{}',
            'with random {C:dark_edition}Spectral{} cards',
            '{C:inactive}(Currently:{} {C:attention}#1#{}{C:inactive}/#2#){}'
        }
    },
    pos = {x = 0, y = 0},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = false,
    discovered = false, 
    cost = 5, 
    rarity = 2,
    config = { extra =  {
        current = 0,
        rounds = 4
    }
},
loc_vars = function(self,info_queue,center)
   return {vars = {center.ability.extra.current, center.ability.extra.rounds}} 
end,
calculate = function(self, card, context) 
     if context.selling_self and (card.ability.extra.current >= card.ability.extra.rounds) and not context.blueprint then
     if not context.individual and not context.repetition and not context.blueprint then
            for i = 1, #G.consumeables.cards do
            G.consumeables.cards[i]:start_dissolve()
            local card_type = 'Spectral'
                G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                G.E_MANAGER:add_event(Event({
                trigger = 'before',
                delay = 0.0,
                func = function()
                local card = create_card(card_type, G.consumeables, nil, nil, nil, nil, nil, nil)
                card:add_to_deck()
                G.consumeables:emplace(card)
                G.GAME.consumeable_buffer = 0
               return true
            end
          })
          )
            end
        end
    end

    if context.end_of_round and context.game_over == false and context.main_eval and not context.blueprint then
      card.ability.extra.current = card.ability.extra.current + 1
      if card.ability.extra.current == card.ability.extra.rounds then
        local eval = function(card) return not card.REMOVED end
        juice_card_until(card, eval, true)
      end
      return {
        message = card.ability.extra.current .. '/' .. card.ability.extra.rounds,
        colour = G.C.BLUE
      }
    end
end

}

SMODS.Joker{
    key = "TJ61",
    loc_txt = {
        name = 'Duplicator',
        text = 
        {
            'Sell this card and',
            'Creates a {C:attention}#1#{} {C:dark_edition}Negative{} copy',
            'of {C:attention}1{} random {C:attention}consumable{}',
            'card in your possession',
        }
    },
    pos = {x = 7, y = 1},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = false,
    discovered = false, 
    cost = 5, 
    rarity = 2,
    config = { extra =  {
        card = 2
    }
},
loc_vars = function(self,info_queue,center)
   return {vars = {center.ability.extra.card}} 
end,
calculate = function(self, card, context) 
     if context.selling_self  then
          if G.consumeables.cards[1] then
                local copy = card.ability.extra.card
                    G.E_MANAGER:add_event(Event({
                        func = function() 
                        for i = 1, copy do
                            local card = copy_card(pseudorandom_element(G.consumeables.cards, pseudoseed('TJ61')), nil)
                            card:set_edition({negative = true}, true)
                            card:add_to_deck()
                            G.consumeables:emplace(card) 
                        end
                            return true
                    end}))
            end
        end
    end
}


SMODS.Joker{
    key = "rene",
    loc_txt = {
        name = 'Rene',
        text = 
        {
            'On the first hand',
            "All {C:attention}listed probabilities{} are",
            "{C:green}guaranteed{}"
        }
    },
    pos = {x = 8, y = 1},
    atlas = 'All_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = false,
    eternal_compat = true,
    discovered = false, 
    cost = 20, 
    soul_pos = { x = 9, y = 1 },
    rarity = 4,--cost
    config = { extra = {
        odds = 1001
    }
},
    loc_vars = function(self,info_queue,center)
    end,
    remove_from_deck = function(self, card, from_debuff)
		for k, v in pairs(G.GAME.probabilities) do
			G.GAME.probabilities[k] = v/card.ability.extra.odds
		end
	end,
     calculate = function(self, card, context)
      if context.first_hand_drawn and G.GAME.current_round.hands_played == 0 then
            for k, v in pairs(G.GAME.probabilities) do 
                  G.GAME.probabilities[k] = 1001
            end
            return {
                message = 'Lucky'
            }
      end
      if context.end_of_round or context.after then
            for k, v in pairs(G.GAME.probabilities) do 
                  G.GAME.probabilities[k] = 1
            end
      end
    end,
    

}

function joker_rarity(legendary)
	if legendary == 0 then
		SMODS.ObjectTypes["Joker"].rarities[4] = nil
	else
		SMODS.ObjectTypes["Joker"].rarities[4] = { key = "Legendary", weight = legendary }
	end
end

SMODS.Joker{
    key = "slasher",
    loc_txt = {
        name = 'Slasher',
        text = 
        {
            'Retrigger',
            'all {C:attention}Steel{} cards',
            'held in hand'
        }
    },
    pos = {x = 0, y = 2},
    atlas = 'All_jokers_atlas',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 20, 
    soul_pos = { x = 1, y = 2},
    rarity = 4,--cost
    config = { extra = {
        retrigger_amt = 1
    }
},
    loc_vars = function(self,info_queue,center)
        info_queue[#info_queue+1] = G.P_CENTERS.m_steel
        return {vars = {center.ability.extra.retrigger_amt}}
    end,

    calculate = function(self,card,context)
        if context.repetition and context.cardarea == G.hand and context.other_card.ability.name == "Steel Card" then
            return
            {
                repetitions = card.ability.extra.retrigger_amt,
                card = card
            }     
        end
    end
}



SMODS.Joker{
    key = "TJ57",
    loc_txt = {
        name = 'Secretino',
        text = 
        {
            '{C:red}Reduce{} the blind',
            'requirement {C:attention}20%{}',
            'in setting the blind'
        }
    },
    pos = {x = 3, y = 2},
    atlas = 'joker_atlas_150',
    unlocked = all_unlocked, 
    blueprint_compat = true,
    eternal_compat = true,
    discovered = false, 
    cost = 20, 
    soul_pos = { x = 4, y = 2},
    rarity = 4,--cost
    config = { extra = {}
},
    loc_vars = function(self,info_queue,center)
        return {vars = {center.ability.extra.retrigger_amt}} 
    end,

    calculate = function(self,card,context)
     if G.GAME.blind and context.setting_blind then
            G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.4,func = function()
                    G.GAME.blind.chips = math.floor(G.GAME.blind.chips * 0.80)
                    G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)

                    local chips_UI = G.hand_text_area.blind_chips
                    G.FUNCS.blind_chip_UI_scale(G.hand_text_area.blind_chips)
                    G.HUD_blind:recalculate() 
                    chips_UI:juice_up()

            
                    if not silent then play_sound('chips2') end
                    
                end }))
            end
    end
}


SMODS.Enhancement {
  key = "ceramic",
  atlas = 'All_enhancements_atlas',
  pos = { x = 2, y = 0 },
      loc_txt = {
        name = 'Ceramic card',
        text = 
        {
            '{X:blue,C:white}X#1#{} Chips',
        }
    },
  discovered = true,
  config = {
        x_chips = 1.5
  },
   loc_vars = function(self, info_queue, center)
    return {
      vars = {
        center.ability.x_chips,
      }
    }
  end,
}

SMODS.Enhancement {
  key = "hanafuda",
  always_scores = true,
  atlas = 'All_enhancements_atlas',
  pos = { x = 5, y = 0 },
      loc_txt = {
        name = 'Hanafuda Card',
        text = 
        {
            'Always',
            'scores'
        }
    },
  discovered = true,
   loc_vars = function(self, info_queue, center)
  end,
}


SMODS.Enhancement {
  key = "cardboard",
  atlas = 'All_enhancements_atlas',
  pos = { x = 6, y = 0 },
      loc_txt = {
        name = 'Cardboard Card',
        text = 
        {
            'Gains {C:red}Mult{}',
            'based on',
            'the card value'
        }
    },
  discovered = true,
  config = {
    extra = {
        h_mult = 0
        
    }
  },
  	override_chip = 0,
   loc_vars = function(self, info_queue, center)
  end,

calculate = function(self, card, context)
if context.cardarea == G.play and context.main_scoring  then
    return
    {
           mult = card.base.nominal,
    }
end
end
}


SMODS.Enhancement {
  key = "miss",
  atlas = 'All_enhancements_atlas',
  pos = { x = 4, y = 0 },
      loc_txt = {
        name = 'MissPrint Card',
        text = 
        {
            'This card randomize',
            'the rank and suit',
            'held in the hand'
        }
    },
  discovered = true,
   loc_vars = function(self, info_queue, center)
  end,
  calculate = function(self, card, context)
        if context.before and context.cardarea == G.hand then
                assert(SMODS.change_base(
                    card,
                    pseudorandom_element(SMODS.Suits, pseudoseed("abstract_miss")).key,
                    pseudorandom_element(SMODS.Ranks, pseudoseed("abstract_miss")).key
                ))
                card:juice_up()
            end
    end
}

SMODS.Seal {
    key = "pink",
    atlas = "All_enhancements_atlas",
    pos = { x = 6, y = 4 },
     loc_txt = {
        name = 'Pink seal',
        text = 
        {
            'If {C:attention}played alone{}',
            'create a {C:attention}copy{} of this card',
            '{C:inactive}(Copies cannot copy the seal){}',

        }
    },
    config = {  },
    badge_colour = HEX('DC6094'),
    calculate = function(self, card, context)
          if context.after and context.full_hand[1] == card then
            if #context.full_hand ~= 1 then return end
            G.playing_card = (G.playing_card and G.playing_card + 1) or 1
            local _c = copy_card(context.full_hand[1], nil, nil, G.playing_card)
            _c:add_to_deck()
            _c:set_seal(nil)
            G.deck.config.card_limit = G.deck.config.card_limit + 1
            table.insert(G.playing_cards, _c)
            G.hand:emplace(_c)
            _c.states.visible = nil

            G.E_MANAGER:add_event(Event({
                func = function()
                    _c:start_materialize()
                    return true
                end
            }))
            return {
                message = 'Cell Divition',
                colour =  HEX('56a786')
            }
        end
    end,
}

SMODS.Seal {
    key = "Bluem",
    atlas = "All_enhancements_atlas",
    pos = { x = 4, y = 4 },
     loc_txt = {
        name = 'Orange seal',
        text = 
        {
             'Gains {C:blue}+3{} Chips',
             '{C:attention}held in hand{}'
        }
    },
    config = {  },
    badge_colour = HEX('FFA83B'),
    calculate = function(self, card, context)
    if context.cardarea == G.hand and context.main_scoring then
          card.ability.bonus = card.ability.bonus + 3
          return {
                message = localize('k_upgrade_ex'),
                card = card,
                colour = G.C.CHIPS
            }
        end
    end
}

SMODS.Seal {
    key = "green",
    atlas = "All_enhancements_atlas",
    pos = { x = 5, y = 4 },
     loc_txt = {
        name = 'Green seal',
        text = 
        {
             'This card',
             'no deffued'
        }
    },
    config = {  },
    badge_colour = HEX('48CF4D'),
    update = function(self, card)
    if card.debuff or card.perma_debuff then
      card.debuff = false
      card.perma_debuff = false
      return true
    end
end
}

SMODS.Seal {
    key = "black",
    atlas = "All_enhancements_atlas",
    pos = { x = 3, y = 4 },
     loc_txt = {
        name = 'Grey seal',
        text = 
        {
            '{C:red}X0.05{} {C:attention}Blind size{}',
            'when score',
        }
    },
    config = {  },
    badge_colour = HEX('757575'),
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
             G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.4,func = function()
                G.GAME.blind.chips = math.floor(G.GAME.blind.chips * 0.95)
                G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)

                local chips_UI = G.hand_text_area.blind_chips
                G.FUNCS.blind_chip_UI_scale(G.hand_text_area.blind_chips)
                G.HUD_blind:recalculate() 
                chips_UI:juice_up()
            
                if not silent then play_sound('chips2') end
                return true end }))
        end
    end
}


SMODS.Consumable{ 
    key = '3spades',
    set = 'Tarot', 
    atlas = 'All_consumables_atlas',
    effect = 'Enhance',
    config = {
    mod_conv = 'm_abstract_ceramic', 
    max_highlighted = 1,
},
    pos = { x = 1, y = 0 },
     loc_txt = {
        name = '3 of swords',
        text = 
        {
            'Enhances{C:attention} 1 {}selected ',
            'card into a', 
            '{C:attention} Ceramic {}card'
        }
    },

    loc_vars = function(self, info_queue)
        info_queue[#info_queue+1] = G.P_CENTERS.m_abstract_ceramic
    end,

}

SMODS.Consumable{ 
    key = 'Acegold',
    set = 'Tarot', 
    atlas = 'All_consumables_atlas',
    effect = 'Enhance',
    config = {
    mod_conv = 'm_abstract_cardboard', 
    max_highlighted = 1,
},
    pos = { x = 0, y = 0 },
     loc_txt = {
        name = 'Ace of Pentacles',
        text = 
        {
            'Enhances{C:attention} 1 {}selected ',
            'card into a', 
            '{C:attention} Cardboard {}card'
        }
    },

    loc_vars = function(self, info_queue)
        info_queue[#info_queue+1] = G.P_CENTERS.m_abstract_cardboard
    end,

}

SMODS.Consumable{ 
    key = 'Acegbastons',
    set = 'Tarot', 
    atlas = 'All_consumables_atlas',
    effect = 'Enhance',
    config = {
    mod_conv = 'm_abstract_hanafuda', 
    max_highlighted = 1,
},
    pos = { x = 2, y = 0 },
     loc_txt = {
        name = 'Ace of Wands',
        text = 
        {
            'Enhances{C:attention} 1 {}selected ',
            'card into a', 
            '{C:attention} Hanafuda {}card'
        }
    },

    loc_vars = function(self, info_queue)
        info_queue[#info_queue+1] = G.P_CENTERS.m_abstract_hanafuda
    end,

}

SMODS.Consumable{ 
    key = '4coups',
    set = 'Tarot', 
    atlas = 'All_consumables_atlas',
    effect = 'Enhance',
    config = {
    mod_conv = 'm_abstract_miss', 
    max_highlighted = 2,
},
    pos = { x = 0, y = 1 },
     loc_txt = {
        name = '5 of Coups',
        text = 
        {
            'Enhances{C:attention} 2 {}selected ',
            'card into a', 
            '{C:attention} Missprint card{}'
        }
    },

    loc_vars = function(self, info_queue)
        info_queue[#info_queue+1] = G.P_CENTERS.m_abstract_miss
    end,

}


SMODS.Consumable{ 
    key = '12moth',
    set = 'Spectral', 
    atlas = 'All_consumables_atlas',
    effect = 'Seal',
    config = { 
        max_highlighted = 1,
        extra ={
        seal = 'abstract_Bluem'
    }
    }, 
    pos = { x = 1, y = 1 },
     loc_txt = {
        name = '12 Months',
        text = 
        {
        'Add a {C:attention}Orange{} seal',
        'to a selected card', 
        }
    },
    loc_vars = function(self, info_queue, card)
        info_queue[#info_queue + 1] = G.P_SEALS[card.ability.extra.seal]
        return { 
            vars = { card.ability.max_highlighted,
            colours = {
                HEX('623938')
            }
         },
        }
    end,
    use = function(self, card, area, copier)
        local conv_card = G.hand.highlighted[1]
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('tarot1')
                card:juice_up(0.3, 0.5)
                return true
            end
        }))

        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.1,
            func = function()
                conv_card:set_seal(card.ability.extra.seal, nil, true)
                return true
            end
        }))

        delay(0.5)
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.2,
            func = function()
                G.hand:unhighlight_all()
                return true
            end
        }))
    end,
}

SMODS.Consumable{ 
    key = 'karma',
    set = 'Spectral', 
    atlas = 'All_consumables_atlas',
    effect = 'Seal',
    config = { 
        max_highlighted = 1,
        extra ={
        seal = 'abstract_green'
    }
    }, 
    pos = { x = 0, y = 2 },
     loc_txt = {
        name = 'Karma',
        text = 
        {
            'Add a {C:attention}Green{} seal',
            'to a selected card', 
        }
    },
    loc_vars = function(self, info_queue, card)
        info_queue[#info_queue + 1] = G.P_SEALS[card.ability.extra.seal]
        return { 
            vars = { card.ability.max_highlighted,
            colours = {
                HEX('623938')
            }
         },
        }
    end,
    use = function(self, card, area, copier)
        local conv_card = G.hand.highlighted[1]
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('tarot1')
                card:juice_up(0.3, 0.5)
                return true
            end
        }))

        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.1,
            func = function()
                conv_card:set_seal(card.ability.extra.seal, nil, true)
                return true
            end
        }))

        delay(0.5)
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.2,
            func = function()
                G.hand:unhighlight_all()
                return true
            end
        }))
    end,
}

SMODS.Consumable{ 
    key = 'hor',
    set = 'Spectral', 
    atlas = 'All_consumables_atlas',
    effect = 'Seal',
    config = { 
        max_highlighted = 1,
        extra ={
        seal = 'abstract_black'
    }
    }, 
    pos = { x = 2, y = 2 },
     loc_txt = {
        name = 'Horror',
        text = 
        {
            'Add a {C:attention}Grey{} seal',
            'to a selected card', 
        }
    },
    loc_vars = function(self, info_queue, card)
        info_queue[#info_queue + 1] = G.P_SEALS[card.ability.extra.seal]
        return { 
            vars = { card.ability.max_highlighted,
            colours = {
                HEX('623938')
            }
         },
        }
    end,
    use = function(self, card, area, copier)
        local conv_card = G.hand.highlighted[1]
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('tarot1')
                card:juice_up(0.3, 0.5)
                return true
            end
        }))

        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.1,
            func = function()
                conv_card:set_seal(card.ability.extra.seal, nil, true)
                return true
            end
        }))

        delay(0.5)
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.2,
            func = function()
                G.hand:unhighlight_all()
                return true
            end
        }))
    end,
}





SMODS.Consumable{ 
    key = 'mito',
    set = 'Spectral', 
    atlas = 'All_consumables_atlas',
    effect = 'Seal',
    config = { 
        max_highlighted = 1,
        extra ={
        seal = 'abstract_pink'
    }
    }, 
    pos = { x = 2, y = 1 },
     loc_txt = {
        name = 'Mitosis',
        text = 
        {
            'Add a {C:attention}Pink{} seal',
            'to a selected card', 
        }
    },
    loc_vars = function(self, info_queue, card)
        info_queue[#info_queue + 1] = G.P_SEALS[card.ability.extra.seal]
        return { 
            vars = { card.ability.max_highlighted,
            colours = {
                HEX('623938')
            }
         },
        }
    end,
    use = function(self, card, area, copier)
        local conv_card = G.hand.highlighted[1]
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('tarot1')
                card:juice_up(0.3, 0.5)
                return true
            end
        }))

        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.1,
            func = function()
                conv_card:set_seal(card.ability.extra.seal, nil, true)
                return true
            end
        }))

        delay(0.5)
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.2,
            func = function()
                G.hand:unhighlight_all()
                return true
            end
        }))
    end,
}


SMODS.Consumable{ 
    key = 'Hekha',
    set = 'Spectral', 
    atlas = 'All_consumables_atlas',
    effect = 'Enhance',
    config = { extra =  {
        delta = -1,
    }}, 
    pos = { x = 3, y = 0 },
     loc_txt = {
        name = 'Hekha & Nekhakha',
        text = 
        {
          'Add {C:dark_edition}Negative{} effect',
          'to a {C:attention}1{} selected card in hand',
        }
    },

can_use = function(self, card)
    return G.hand and G.jokers
        and #G.hand.highlighted == 1
        and not G.hand.highlighted[1].edition
  end,

  use = function(self, card, area, copier)
    local other_card = G.hand.highlighted[1]
      other_card:set_edition('e_negative')
  end

}

SMODS.Consumable{ 
    key = 'Ouro',
    set = 'Spectral', 
    atlas = 'All_consumables_atlas',
    effect = 'Enhance',
    config = { extra =  {
       
    }}, 
    pos = { x = 1, y = 2 },
     loc_txt = {
        name = 'Ouroboros',
        text = 
        {

          'Create a {C:dark_edition}Eternal{} copy',
          'of selected Joker',
          '{C:inactive}(Must have room){}'
        }
    },
  
    can_use = function(self, card)
      if #G.jokers.highlighted == 1 and #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit 
         then 
        return true 
        else
         return false 

         end
    end,
  
    use = function(self, card, area, copier)
      G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.4, func = function()
        play_sound('timpani')
        local copy = copy_card(G.jokers.highlighted[1], nil, nil, nil, true)
        copy:add_sticker('eternal', true)
        copy:add_to_deck()
        G.jokers:emplace(copy)
        card:juice_up(0.3, 0.5)
        return true end }))
      delay(0.6)
      return true
    end

}



SMODS.Back({
    key = "hanadeck", 
    atlas = "All_enhancements_atlas",
    pos = {x = 2, y = 1}, 
    config = {  selection_size = 1,},
    loc_txt = {
        name = 'Hanafuda Deck',
        text = 
        {
            'All cards are',
            '{C:red}Hanafuda cards{}',
            '{C:attention}+1{} cards selection limit',
        }
    },
    apply = function(self)
         G.E_MANAGER:add_event(Event({
                trigger = "after",
                func = (function()
                    G.hand.config.highlighted_limit = G.hand.config.highlighted_limit + self.config.selection_size
                    if SMODS.change_play_limit and SMODS.change_discard_limit then
                        SMODS.change_play_limit(1)
                        SMODS.change_discard_limit(1)
                    end
                    return true
                end)
        }))


        G.E_MANAGER:add_event(Event({
            func = function()
                local ranks = {}
                for k, rank in pairs(SMODS.Ranks) do
                    ranks[rank.id] = pseudorandom_element({'Spades','Hearts','Diamonds','Clubs'})
                end
                for k, v in pairs(G.playing_cards) do
                    v:set_ability(G.P_CENTERS['m_abstract_hanafuda'])
                end
                return true
            end
        }))
    end,
    loc_vars = function(self, info_queue, card)
        return {vars = {self.config.m_abstract_hanafuda}}
    end,
})

SMODS.Back({
    key = "Cera", 
    atlas = "All_enhancements_atlas",
    pos = {x = 2, y = 0}, 
    config = {
    },
    loc_txt = {
        name = 'Ceramic Deck',
        text = 
        {
            'All {C:attention}Face cards{}',
            'are {C:blue}Ceramic{} cards',
            'All {C:attention}3{} and {C:attention}2{}',
            'are bonus cards',
            'Remove all {C:attention}Aces{} for the deck',
        }
    },
    apply = function(self)
        G.E_MANAGER:add_event(Event({
            func = function()
                local faces = {}
                for k, rank in pairs(SMODS.Ranks) do
                    if rank.face then faces[#faces + 1] = k end
                end
                for k, v in pairs(G.playing_cards) do
                    if v:is_face() then
                       v:set_ability(G.P_CENTERS['m_abstract_ceramic'])
                    elseif v:get_id() == 3 or v:get_id() == 2 then
                       v:set_ability(G.P_CENTERS['m_bonus'])
                    elseif v:get_id() == 14 then
                        v.to_remove = true
                    end 
                end
                local i = 1
                while i <= #G.playing_cards do
                    if G.playing_cards[i].to_remove then
                        G.playing_cards[i]:remove()
                    else
                        i = i + 1
                    end
                end
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
    end,
      loc_vars = function(self, info_queue, card)
        return {vars = {self.config.m_abstract_ceramic}}
    end,
})

SMODS.Back({
    key = "Board", 
    atlas = "All_enhancements_atlas",
    pos = {x = 3, y = 1}, 
    config = {
  },
    loc_txt = {
        name = 'Cardboard Deck',
        text = 
        {
            'All cards are {C:attention}Carboard{} cards',
            'Remove higher cards than',
            '{C:attention}5{} for the deck',
        }
    },
    apply = function(self)
        G.E_MANAGER:add_event(Event({
            func = function()
                local faces = {}
                for k, rank in pairs(SMODS.Ranks) do
                    if rank.face then faces[#faces + 1] = k end
                end
                for k, v in pairs(G.playing_cards) do
                    if v:is_face() or v:get_id() > 5  then 
                        v.to_remove = true
                    else
                        v:set_ability(G.P_CENTERS['m_abstract_cardboard'])
                    end 
                end
                local i = 1
                while i <= #G.playing_cards do
                    if G.playing_cards[i].to_remove then
                        G.playing_cards[i]:remove()
                    else
                        i = i + 1
                    end
                end
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
    end,
      loc_vars = function(self, info_queue, card)
        return {vars = {self.config.m_abstract_cardboard}}
    end,
})

SMODS.Back({
    key = "Mer", 
    atlas = "All_enhancements_atlas",
    pos = {x = 0, y = 1}, 
    config = { 
        vouchers = {
        'v_overstock_norm',
        'v_overstock_plus'
        }
  },
    loc_txt = {
        name = 'Postal Deck',
        text = 
        {
            'Start with {C:attention}Overstock{} and {C:attention}Oversotck Plus{}',
            'The shop {C:attention}increases{} its capacity',
            'Items cost {C:attention}$1{} more'
        }
    },

    apply = function(self)
       SMODS.change_voucher_limit(1)
       G.GAME.inflation = G.GAME.inflation + 1
    end,
})

SMODS.Back({
    key = "missdeck", 
    atlas = "All_enhancements_atlas",
    pos = {x = 0, y = 0}, 
    config = {  selection_size = 1,},
    loc_txt = {
        name = 'MissPrint Deck',
        text = 
        {
            'All cards are',
            '{C:red}MissPrint cards{}',
        }
    },
       apply = function(self)
        G.E_MANAGER:add_event(Event({
            func = function()
                local ranks = {}
                for k, rank in pairs(SMODS.Ranks) do
                    ranks[rank.id] = pseudorandom_element({'Spades','Hearts','Diamonds','Clubs'})
                end
                for k, v in pairs(G.playing_cards) do
                    v:set_ability(G.P_CENTERS['m_abstract_miss'])
                end
                return true
            end
        }))
    end,
    loc_vars = function(self, info_queue, card)
        return {vars = {self.config.m_abstract_miss}}
    end,
})

SMODS.Voucher({
	key = "V1",
	atlas = "All_vouchers_atlas",
	pos = {x = 0, y = 3},
	cost = 10,
	unlocked = true,
	discovered = false,
     loc_txt = {
        name = 'Spoon',
        text = 
        {
           '{C:attention}+#1#{} booster pack in the shop '
        }
    },
	available = true,
	config = {extra = {booster = 1}},
	redeem = function(self, card)
        SMODS.change_booster_limit(card.ability.extra.booster)
    end,
    unredeem = function(self, voucher)
		SMODS.change_booster_limit(-card.ability.extra.boosters)
	end,
    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.booster}}
    end,
})

SMODS.Voucher({
	key = "UPGV1",
	atlas = "All_vouchers_atlas",
	pos = {x = 1, y = 3},
	cost = 10,
	unlocked = true,
	discovered = false,
     loc_txt = {
        name = 'Spoon Bender',
        text = 
        {
            '{C:attention}+1{} card selection in the',
            'booster packs',
        }
    },
	available = false,
    requires = {'v_abstract_V1'},
	config = {extra = {card_limit = 1}},
    redeem = function(self, voucher)
		G.GAME.modifiers.booster_size_mod = (G.GAME.modifiers.booster_size_mod or 0) + 1
	end,
	unredeem = function(self, voucher)
		G.GAME.modifiers.booster_size_mod = (G.GAME.modifiers.booster_size_mod or 0) - 1
	end,
})

SMODS.Voucher({
	key = "V3",
	atlas = "All_vouchers_atlas",
	pos = {x = 0, y = 1},
	cost = 10,
	unlocked = true,
	discovered = false,
     loc_txt = {
        name = 'Carisma',
        text = 
        {
            '{C:attention}1{} free {C:green}Reroll{} per shop'
        }
    },
	available = true,
	config = {extra = {rerolls = 1}},
   redeem = function(self, card)
        G.E_MANAGER:add_event(Event({func = function()
            SMODS.change_free_rerolls(card.ability.extra.rerolls)
            return true 
        end }))
    end,
})


SMODS.Voucher({
	key = "UPGV3",
	atlas = "All_vouchers_atlas",
	pos = {x = 1, y = 1},
	cost = 10,
	unlocked = true,
	discovered = false,
     loc_txt = {
        name = 'Chetear',
        text = 
        {
            'Doubles all {C:attention}listed{} {C:green}probabilities{}',
            '{C:inactive}(ex:{} {C:green}1 in 3{} {C:inactive}->{} {C:green}2 in 3{}{C:inactive}){}'
        }
    },
    requires = {'v_abstract_V2'},
	available = true,
	config = {extra = {booster = 1}},
    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.booster}}
    end,
    redeem = function(self, card)
         G.E_MANAGER:add_event(Event({
            func = function()
                G.GAME.probabilities.normal = (G.GAME.probabilities.normal or 1) * 2
                return true
            end
        }))
	end,

})


SMODS.Voucher({
	key = "V4",
	atlas = "All_vouchers_atlas",
	pos = {x = 0, y = 0},
	cost = 10,
	unlocked = true,
	discovered = false,
     loc_txt = {
        name = 'Collector',
        text = 
        {
            '{C:attention}+1{} card selection limit'
        }
    },
	available = true,
	config = {extra = {rerolls = 1}},
   redeem = function(self, card)
       SMODS.change_play_limit(1)
	   SMODS.change_discard_limit(1)
    end,
    unredeem = function(self, voucher)
		 SMODS.change_play_limit(-1)
	   SMODS.change_discard_limit(-1)
	end
})

SMODS.Voucher({
	key = "UPGV4",
	atlas = "All_vouchers_atlas",
	pos = {x = 1, y = 0},
    requires = {'v_abstract_V4'},
	cost = 10,
	unlocked = true,
	discovered = false,
     loc_txt = {
        name = 'Obsessed',
        text = 
        {
            '{C:attention}+1{} card selection limit'
        }
    },
	available = true,
	config = {extra = {rerolls = 1}},
   redeem = function(self, card)
        SMODS.change_play_limit(1)
	    SMODS.change_discard_limit(1)
    end,
    unredeem = function(self, voucher)
		 SMODS.change_play_limit(-1)
	   SMODS.change_discard_limit(-1)
	end
})

SMODS.Voucher({
	key = "V5",
	atlas = "All_vouchers_atlas",
	pos = {x = 0, y = 2},
	cost = 10,
	unlocked = true,
	discovered = false,
     loc_txt = {
        name = 'Sweet Victory',
        text = 
        {
            'Create a {C:attention}random Tag{}',
            'when {C:attention}Boss Blind{} is defeated'
        }
    },
	available = true,
	config = {extra = {}},
calculate = function(self, card, context) 
    if context.end_of_round and context.main_eval and G.GAME.blind.boss then
     G.E_MANAGER:add_event(Event({
            func = (function()
                    local tag_key = get_next_tag_key()
                    add_tag(Tag(tag_key))
                return true
            end),
        }))
        delay(0.6)
    end
end
})

SMODS.Voucher({
	key = "UPGV5",
	atlas = "All_vouchers_atlas",
	pos = {x = 1, y = 2},
	cost = 10,
     requires = {'v_abstract_V5'},
	unlocked = true,
	discovered = false,
     loc_txt = {
        name = 'Sweet Cake',
        text = 
        {
            'Create a {C:attention}random Tag{}',
            'when {C:attention}Small{} Blind',
            'is defeated'
        }
    },
	available = true,
	config = {extra = {}},
calculate = function(self, card, context) 
    if context.end_of_round and context.main_eval and G.GAME.blind:get_type() == 'Small' then
     G.E_MANAGER:add_event(Event({
            func = (function()
                    local tag_key = get_next_tag_key()
                    add_tag(Tag(tag_key))
                return true
            end),
        }))
        delay(0.6)
    end
end
})

SMODS.Challenge {
    key = "Chan3",
      loc_txt = {
        name = 'Damocles Challenge',
    },
    rules = {
    },
    jokers = {
        {id = 'j_abstract_TJ52', eternal = true},
    },
      deck = {
         type = 'Challenge Deck',
        cards = {
            -- CLUBS
            { s = 'C', r = 'A'},
            { s = 'C', r = 'K'},
            { s = 'C', r = 'Q'},
            { s = 'C', r = 'J'},
            { s = 'C', r = 'T'},
            { s = 'C', r = '9'},
            { s = 'C', r = '8'},
            { s = 'C', r = '7'},
            { s = 'C', r = '6'},
            { s = 'C', r = '5'},
            { s = 'C', r = '4'},
            { s = 'C', r = '3'},
            { s = 'C', r = '2'},
             -- HEARTS
            { s = 'H', r = 'A'},
            { s = 'H', r = 'K'},
            { s = 'H', r = 'Q'},
            { s = 'H', r = 'J'},
            { s = 'H', r = 'T'},
            { s = 'H', r = '9'},
            { s = 'H', r = '8'},
            { s = 'H', r = '7'},
            { s = 'H', r = '6'},
            { s = 'H', r = '5'},
            { s = 'H', r = '4'},
            { s = 'H', r = '3'},
            { s = 'H', r = '2'},
              -- DIAMONDS
            { s = 'D', r = 'A'},
            { s = 'D', r = 'K'},
            { s = 'D', r = 'Q'},
            { s = 'D', r = 'J'},
            { s = 'D', r = 'T'},
            { s = 'D', r = '9'},
            { s = 'D', r = '8'},
            { s = 'D', r = '7'},
            { s = 'D', r = '6'},
            { s = 'D', r = '5'},
            { s = 'D', r = '4'},
            { s = 'D', r = '3'},
            { s = 'D', r = '2'},
            -- Spades
            { s = 'S', r = 'A'},
            { s = 'S', r = 'K'},
            { s = 'S', r = 'Q'},
            { s = 'S', r = 'J'},
            { s = 'S', r = 'T'},
            { s = 'S', r = '9'},
            { s = 'S', r = '8'},
            { s = 'S', r = '7'},
            { s = 'S', r = '6'},
            { s = 'S', r = '5'},
            { s = 'S', r = '4'},
            { s = 'S', r = '3'},
            { s = 'S', r = '2'},
        }
    },
    restrictions = {
        banned_cards = {

        }
    }
}
----------------------------------------------
------------MOD CODE END----------------------
    
